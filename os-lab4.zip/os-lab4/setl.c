#include "types.h"
#include "stat.h"
#include "user.h"

#define STDOUT 1

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf(STDOUT, "bad argument\n");

    }
    setl(atoi(argv[1]), atoi(argv[2]));
    exit();
}
