#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"

int
sys_fork(void)
{
  return fork(ticks);
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

// added
int
sys_calculateBPS(void)
{
  int num = myproc()->tf->ebx;
  cprintf("(k-mode) value in register edx = %d\n", num);

  int i = 0;
  while(i*i < num)
  {
    i++;
  }
  return i-1;
}

// added
int
sys_processStartTime(void)
{
  return myproc()->startTime;
}

// added
int sys_getAncestors(void)
{
  int pid;
  if (argint(0, &pid) < 0)
    return -1;

  if(pid < 0)
    return -1;

  int curr = pid;
  int prev = pid;
  while(curr > 0)
  {
    curr = giveParent(curr);
    if(curr == -1)
      break;
    cprintf("my id: %d, ", prev);

    cprintf("my parent id: %d\n", curr);
    prev = curr;
  }

  return 1;
}

// added
int sys_setSleep(void)
{
  struct rtcdate r1;
  cmostime(&r1);
  uint ticks0 = ticks;
  // cprintf("start time(sec) = %d s\n", r1.second);
  // cprintf("-start time(ticks) = %d ticks\n", ticks0);

  // uint ticks0;
  int time;
  if (argint(0, &time) < 0)
    return -1;
  time *= 100;

  acquire(&tickslock);
  while (ticks - ticks0 < time)
  {
    if (myproc()->killed)
      return -1;

    release(&tickslock);
    sti();
    acquire(&tickslock);
  }
  release(&tickslock);

  uint ticks1 = ticks;
  struct rtcdate r2;
  cmostime(&r2);
  // cprintf("end time(sec) = %d s\n", r2.second);
  // cprintf("-end time(ticks) = %d ticks\n", ticks1);
  cprintf("-duration(sec) = %d s\n", r2.second - r1.second);
  cprintf("-duration(ticks) = %d ticks\n", ticks1 - ticks0);

  return 1;
}

//added
int sys_getDescendants(void)
{
  int pid;
  if (argint(0, &pid) < 0)
    return -1;

  if(pid < 0)
    return -1;

  int curr = pid;
  int prev = pid;
  while(curr > 0)
  {
    curr = giveYoungestChild(curr);
    if(curr == -1)
      break;
    cprintf("my id: %d, ", prev);

    cprintf("my child id: %d\n", curr);
    prev = curr;
  }

  return 1;
}

//added
int sys_plog(void) {
  plog();
  return 0;
}

//added
int sys_setp(void)
{
  int pid;
  int p;
  if (argint(0, &pid) < 0)
    return -1;
  if (argint(1, &p) < 0)
    return -1;

  setp(pid, p);
  return 0;
}

//added
int sys_setl(void)
{
  int pid;
  int level;
  if (argint(0, &pid) < 0 || argint(1, &level) < 0)
    return -1;

  if (pid < 0)
    return -1;

  if (level < 1 || level > 4)  
    return -1;
  
  if (setLevel(pid, level))
    return -1;
  return 0;
}

//added 
int sys_setr(void)
{
  int pid;
  int ratio_p;
  int ratio_a;
  int ratio_e;

  if (argint(0, &pid) < 0) 
    return -1;

  if ((argint(1, &ratio_p) < 0) || (argint(2, &ratio_a) < 0) || (argint(3, &ratio_e) < 0))
    return -1;

  if (pid < 0)
    return -1;
  
  if (setRatio(pid, ratio_p, ratio_a, ratio_e))
    return -1;
  return 0;
}

//added
struct {
  struct spinlock lock;
} testSpinlock;

int recfuncTest(int i)
{
  if (i == 0)
    return 0;
  acquire(&testSpinlock.lock);
  i = i - 1;
  recfuncTest(i);
  release(&testSpinlock.lock);
  return 0;
}

//added
int spinlockTest(void)
{
  int i;
  if (argint(0, &i) < 0)
    return -1;
  initlock(&testSpinlock.lock, "testSpinlock");
  recfuncTest(i);
  return 0;
}
