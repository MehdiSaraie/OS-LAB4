#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"
#include "spinlock.h"

struct {
  struct spinlock lock;
  struct proc proc[NPROC];

  struct proc *levels[4]; //added
} ptable;

static struct proc *initproc;

int nextpid = 1;
extern void forkret(void);
extern void trapret(void);

static void wakeup1(void *chan);

// added
void printFloat(float a) {
  cprintf("%d", (int)a);
  cprintf(".");
  cprintf("%d", (int)((a - (int)a) * 10));
  cprintf("%d", (int)(((10 * a) - (int)(10 * a)) * 10));
}

//added
char *enumToChar(int e)
{
  if (e == 0)
    return "UNUSED";
  else if (e == 1)
    return "EMBRYO";
  else if (e == 2)
    return "SLEEPING";
  else if (e == 3)
    return "RUNNABLE";
  else if (e == 4)
    return "RUNNING";
  else if (e == 5)
    return "ZOMBIE";
  else
    return "NOT_FOUND";
}

// added
void printLL(struct proc *head)
{
  struct proc *cursor = head;

  if (head == 0) {
    cprintf("NULL\n");
    return;
  }

  while (1) {
    if (cursor->hasNext != 1)
    {
      cprintf("-> %d(", cursor->pid);
      cprintf(enumToChar(cursor->state));
      cprintf(") ");
      break;
    }
    cprintf("-> %d(", cursor->pid);
    cprintf(enumToChar(cursor->state));
    cprintf(") ");
    cursor = cursor->next;
  }
  cprintf("\n");
}

// added
int length(struct proc *head, int state)
{
  if (head == 0)
    return 0;

  int counter = 1;
  struct proc *cursor = head;
  while(1) {
    if (cursor->hasNext == 0)
      break;
    cursor = cursor->next;
    if(state == 1) {
      if((cursor->state == RUNNABLE) || (cursor->state == RUNNING))
        counter++;
    }
    else if(state == -1)
      counter++;
  }

  return counter;
}

// added
void addToLL(struct proc **head, struct proc *new, int index)
{
  struct proc *prev = *head;
  struct proc *cursor = *head;

  for(int i=0; i<index; i++) {
    cursor = cursor->next;
    if (i != 0)
      prev = prev->next;
  }

  if (index == length(*head, -1)) {
    new->hasNext = 0;
  }
  else {
    new->next = cursor;
    new->hasNext = 1;
  }
  if (index == 0)
    *head = new;
  else {
    prev->next = new;
    prev->hasNext = 1;
  }

}

// added
struct proc* removeFromLL(struct proc **head, int index)
{
  struct proc *prev = *head;
  struct proc *cursor = *head;

  for (int i = 0; i < index; i++) {
    cursor = cursor->next;
    if (i != 0)
      prev = prev->next;
  }

  if(index == 0) {
    if (length(*head, -1) == 1)
      *head = 0;
    else
      *head = cursor->next;
  }
  else {
    if (index == (length(*head, -1) - 1)) {
      prev->hasNext = 0;
    }
    else
      prev->next = cursor->next;
  }
  cursor->hasNext = 0;
  return cursor;
}

// added
int findNode(struct proc *head, int pid)
{
  struct proc *cursor = head;

  int counter = 0;
  while (1)
  {
    if(cursor->pid == pid) {
      return counter;
    }
    if (cursor->hasNext == 0)
      break;

    counter++;
    cursor = cursor->next;
  }

  return -1;
}

// added
int getFirstCame(struct proc *head)
{
  struct proc *cursor = head;
  if (head == 0)
    return -1;

  int counter = 0;
  while(1) {
    if(cursor->state == RUNNABLE)
      return counter;
    
    if(cursor->hasNext == 0)
      break;
    
    counter++;
    cursor = cursor->next;
  }

  return -1;
}


// added
void updateRank(struct proc* p) {
  p->rank = (p->priority * p->priority_ratio / 100) +
            (p->startTime * p->arrTime_ratio / 100) +
            (p->execTime * p->execTime_ratio / 100);
}

// added
int getLowest(struct proc *head, int level)
{
  struct proc *cursor = head;

  if (head == 0)
    return -1;

  int min = -1;
  int minIndex = -1;

  int counter = 0;
  while(1) {
    if(min == -1) {
      if (cursor->state == RUNNABLE) {
        minIndex = counter;
        if (level == 2)
          min = cursor->priority;
        else if (level == 3)
          min = cursor->rank;
        else if (level == 4)
          min = cursor->startTime;
      }
    }
    else if(cursor->state == RUNNABLE) {
      if (level == 2 && cursor->priority < min) {
        min = cursor->priority;
        minIndex = counter;
      }
      else if (level == 3 && cursor->rank < min) {
        min = cursor->rank;
        minIndex = counter;
      }
      else if (level == 4 && cursor->startTime < min) {
        min = cursor->startTime;
        minIndex = counter;
      }
    }
    if(cursor->hasNext == 0)
      break;
    
    counter++;
    cursor = cursor->next;
  }

  return minIndex;
}

// added
struct proc* selectLevel1() {
  struct proc *chosen = 0;
  int chosenIndex = getFirstCame(ptable.levels[0]);

  if (chosenIndex == -1)  // nothing to process in this Queue
    return 0;

  chosen = removeFromLL(&ptable.levels[0], chosenIndex);
  addToLL(&ptable.levels[0], chosen, length(ptable.levels[0], -1));
  // cprintf("chosen:%d***pid:%d***level:%d***state:%d\n", chosen, chosen->pid, chosen->level, chosen->state);
  return chosen;
}

// added
struct proc* selectLevel2() {
  struct proc *chosen = 0;
  int chosenIndex = getLowest(ptable.levels[1], 2);

  if (chosenIndex == -1)  // nothing to process in this Queue
    return 0;

  chosen = removeFromLL(&ptable.levels[1], chosenIndex);
  addToLL(&ptable.levels[1], chosen, length(ptable.levels[1], -1));
  // addToLL(&ptable.levels[1], chosen, chosenIndex);

  // cprintf("chosen:%d***pid:%d***level:%d***state:%d\n", chosen, chosen->pid, chosen->level, chosen->state);
  return chosen;
}

// added
struct proc* selectLevel3() {
  struct proc *chosen = 0;
  int chosenIndex = getLowest(ptable.levels[2], 3);

  if (chosenIndex == -1)  // nothing to process in this Queue
    return 0;

  chosen = removeFromLL(&ptable.levels[2], chosenIndex);
  // addToLL(&ptable.levels[2], chosen, length(ptable.levels[2], -1));
  addToLL(&ptable.levels[2], chosen, chosenIndex);

  // cprintf("chosen:%d***pid:%d***level:%d***state:%d\n", chosen, chosen->pid, chosen->level, chosen->state);
  return chosen;
}

//added
struct proc* selectLevel4() {
  struct proc *chosen = 0;
  int chosenIndex = getLowest(ptable.levels[3], 4);

  if (chosenIndex == -1)  // nothing to process in this Queue
    return 0;

  chosen = removeFromLL(&ptable.levels[3], chosenIndex);
  // addToLL(&ptable.levels[3], chosen, length(ptable.levels[3], -1));
  addToLL(&ptable.levels[3], chosen, chosenIndex);

  // cprintf("chosen:%d***pid:%d***level:%d***state:%d\n", chosen, chosen->pid, chosen->level, chosen->state);
  return chosen;
}

// added
int plog(void)
{
    acquire(&ptable.lock);

    struct proc *p;

    cprintf("\n");
    cprintf("--------------------------------------------------\n");

    for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    {
      if (p->state != UNUSED)
      {
        cprintf("%d", p->pid);
        cprintf(" * ");
        cprintf(p->name);
        cprintf(" * ");
        
        cprintf(enumToChar(p->state));
        cprintf("   ");
        cprintf("lev:%d", p->level);
        cprintf(" / ");
        cprintf("pri:%d", p->priority);
        cprintf(" / ");
        
        cprintf("arr_time:%d", p->startTime);
        cprintf(" / ");
        cprintf("execTime:");
        printFloat(p->execTime);
        cprintf(" / ");
        cprintf("age:%d", p->age);
        cprintf(" / ");
        cprintf("pri_ratio:%d%s", p->priority_ratio, "%");
        cprintf(" / ");
        cprintf("arr_ratio:%d%s", p->arrTime_ratio, "%");
        cprintf(" / ");
        cprintf("exe_ratio:%d%s", p->execTime_ratio, "%");
        cprintf(" / ");
        cprintf("rank:");
        printFloat(p->rank);
        cprintf("\n");
      }
    }
    cprintf("\nQ1: ");
    printLL(ptable.levels[0]);
    cprintf("Q2: ");
    printLL(ptable.levels[1]);
    cprintf("Q3: ");
    printLL(ptable.levels[2]);
    cprintf("Q4: ");
    printLL(ptable.levels[3]);
    cprintf("--------------------------------------------------\n\n");

    release(&ptable.lock);
    return 0;
}

// added
int setp(int pid, int priority) {
  struct proc *p;

  acquire(&ptable.lock);
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++) {
    if (p->pid == pid) {
      p->priority = priority;
      updateRank(p);
    }
  }
  release(&ptable.lock);
  return 0;
}

//added
int setLevel(int pid, int l)
{
  struct proc *p;
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->pid == pid)
    {
      int lev = p->level - 1;
      struct proc *rem = removeFromLL(&ptable.levels[lev], findNode(ptable.levels[lev], p->pid));
      rem->level = l;
      rem->age = 0;
      rem->startTime = ticks;
      updateRank(rem);
      addToLL(&ptable.levels[l-1], rem, length(ptable.levels[l-1], -1));
      return 0;
    }
  }
  return 1;
}

//added
int setRatio(int pid, int priority_ratio, int arrTime_ratio, int execTime_ratio) 
{
  struct proc *p;
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->pid == pid)
    {
      p->priority_ratio = priority_ratio;
      p->arrTime_ratio = arrTime_ratio;
      p->execTime_ratio = execTime_ratio;
      updateRank(p);
      // p->rank = (p->priority*p->priority_ratio/100)+(p->startTime*p->arrTime_ratio/100)+(p->execTime*p->execTime_ratio/100);
      return 0;
    }
  }
  return 1;
}

//added
void incAge()
{
  struct proc *p;
  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++) {
    if (p->state == RUNNABLE)
      p->age++;
    if ((p->age >= 8000) && (p->level > 1))
      	setLevel(p->pid, p->level - 1);
  }
}


//added Return a integer between 0 and ((2^32 - 1) / 2), which is 2147483647.
uint
random(void)
{
  static unsigned int z1 = 12345, z2 = 12345, z3 = 12345, z4 = 12345;
  unsigned int b;
  b  = ((z1 << 6) ^ z1) >> 13;
  z1 = ((z1 & 4294967294U) << 18) ^ b;
  b  = ((z2 << 2) ^ z2) >> 27; 
  z2 = ((z2 & 4294967288U) << 2) ^ b;
  b  = ((z3 << 13) ^ z3) >> 21;
  z3 = ((z3 & 4294967280U) << 7) ^ b;
  b  = ((z4 << 3) ^ z4) >> 12;
  z4 = ((z4 & 4294967168U) << 13) ^ b;

  return (z1 ^ z2 ^ z3 ^ z4) / 2;
}

// Return a random integer between a given range.
int
randomrange(int lo, int hi)
{
  int range = hi - lo + 1;
  return random() % (range) + lo;
}

void
pinit(void)
{
  initlock(&ptable.lock, "ptable");
}

// Must be called with interrupts disabled
int cpuid()
{
  return mycpu() - cpus;
}

// Must be called with interrupts disabled to avoid the caller being
// rescheduled between reading lapicid and running through the loop.
struct cpu *
mycpu(void)
{
  int apicid, i;

  if (readeflags() & FL_IF)
    panic("mycpu called with interrupts enabled\n");

  apicid = lapicid();
  // APIC IDs are not guaranteed to be contiguous. Maybe we should have
  // a reverse map, or reserve a register to store &cpus[i].
  for (i = 0; i < ncpu; ++i)
  {
    if (cpus[i].apicid == apicid)
      return &cpus[i];
  }
  panic("unknown apicid\n");
}

// Disable interrupts so that we are not rescheduled
// while reading proc from the cpu structure
struct proc *
myproc(void)
{
  struct cpu *c;
  struct proc *p;
  pushcli();
  c = mycpu();
  p = c->proc;
  popcli();
  return p;
}

//PAGEBREAK: 32
// Look in the process table for an UNUSED proc.
// If found, change state to EMBRYO and initialize
// state required to run in the kernel.
// Otherwise return 0.
static struct proc *
allocproc(void)
{
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if (p->state == UNUSED)
      goto found;

  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO;
  p->pid = nextpid++;
  // added
  if (p->pid == 1) {
  	for (int j = 0; j < 4; j++)
      ptable.levels[j] = 0;
  }
  p->startTime = ticks;
  p->execTime = 0.0;
  p->priority = 50;
  p->level = 2;
  p->priority_ratio = randomrange(1,100);
  p->arrTime_ratio = randomrange(1,100);
  p->execTime_ratio = randomrange(1,100);
  p->age = 0;
  updateRank(p);
  // p->rank = (p->priority*p->priority_ratio/100)+(p->startTime*p->arrTime_ratio/100)+(p->execTime*p->execTime_ratio/100);
  
  addToLL(&ptable.levels[1], p, length(ptable.levels[1], -1));
  // printLL(ptable.levels[1]);

  release(&ptable.lock);

  // Allocate kernel stack.
  if ((p->kstack = kalloc()) == 0)
  {
    p->state = UNUSED;
    return 0;
  }
  sp = p->kstack + KSTACKSIZE;

  // Leave room for trap frame.
  sp -= sizeof *p->tf;
  p->tf = (struct trapframe *)sp;

  // Set up new context to start executing at forkret,
  // which returns to trapret.
  sp -= 4;
  *(uint *)sp = (uint)trapret;

  sp -= sizeof *p->context;
  p->context = (struct context *)sp;
  memset(p->context, 0, sizeof *p->context);
  p->context->eip = (uint)forkret;

  // cprintf("allocproc***pid:%d\n", p->pid);
  return p;
}

//PAGEBREAK: 32
// Set up first user process.
void
userinit(void)
{
  struct proc *p;
  extern char _binary_initcode_start[], _binary_initcode_size[];

  p = allocproc();

  initproc = p;
  if ((p->pgdir = setupkvm()) == 0)
    panic("userinit: out of memory?");
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
  p->sz = PGSIZE;
  memset(p->tf, 0, sizeof(*p->tf));
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
  p->tf->es = p->tf->ds;
  p->tf->ss = p->tf->ds;
  p->tf->eflags = FL_IF;
  p->tf->esp = PGSIZE;
  p->tf->eip = 0; // beginning of initcode.S

  safestrcpy(p->name, "initcode", sizeof(p->name));
  p->cwd = namei("/");

  // this assignment to p->state lets other cores
  // run this process. the acquire forces the above
  // writes to be visible, and the lock is also needed
  // because the assignment might not be atomic.
  acquire(&ptable.lock);

  p->state = RUNNABLE;

  release(&ptable.lock);
}

// Grow current process's memory by n bytes.
// Return 0 on success, -1 on failure.
int growproc(int n)
{
  uint sz;
  struct proc *curproc = myproc();

  sz = curproc->sz;
  if (n > 0)
  {
    if ((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
      return -1;
  } else if(n < 0){
  if((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
    return -1;
  }
  curproc->sz = sz;
  switchuvm(curproc);
  return 0;
}

// Create a new process copying p as the parent.
// Sets up stack to return as if from system call.
// Caller must set state of returned proc to RUNNABLE.
int
fork(uint ticks)
{
  int i, pid;
  struct proc *np;
  struct proc *curproc = myproc();

  // Allocate process.
  if((np = allocproc()) == 0){
    return -1;
  }

  // Copy process state from proc.
  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){
    kfree(np->kstack);
    np->kstack = 0;
    np->state = UNUSED;
    return -1;
  }
  np->sz = curproc->sz;
  np->parent = curproc;
  *np->tf = *curproc->tf;
  
  // added - set child
  np->hasChild = 0;
  struct proc *parent = np->parent;
  if (!parent->hasChild || parent->youngestChild->startTime > np->startTime) {
    parent->youngestChild = np;
    parent->hasChild = 1;
  }

  // Clear %eax so that fork returns 0 in the child.
  np->tf->eax = 0;

  for(i = 0; i < NOFILE; i++)
    if(curproc->ofile[i])
      np->ofile[i] = filedup(curproc->ofile[i]);
  np->cwd = idup(curproc->cwd);

  safestrcpy(np->name, curproc->name, sizeof(curproc->name));

  pid = np->pid;

  acquire(&ptable.lock);
  np->state = RUNNABLE;
  release(&ptable.lock);
  return pid;
}

// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait() to find out it exited.
void
exit(void)
{
  struct proc *curproc = myproc();
  struct proc *p;
  int fd;

  if(curproc == initproc)
    panic("init exiting");

  // Close all open files.
  for(fd = 0; fd < NOFILE; fd++){
    if(curproc->ofile[fd]){
      fileclose(curproc->ofile[fd]);
      curproc->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(curproc->cwd);
  end_op();
  curproc->cwd = 0;

  acquire(&ptable.lock);

  // added
  // cprintf("exit pid: %d and index: %d\n", curproc->pid, findNode(ptable.level2, curproc->pid));
  int lev = curproc->level - 1;
  removeFromLL(&ptable.levels[lev], findNode(ptable.levels[lev], curproc->pid));

  // printLL(ptable.level2);

  // Parent might be sleeping in wait().
  wakeup1(curproc->parent);

  // Pass abandoned children to init.
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->parent == curproc){
      p->parent = initproc;
      if(p->state == ZOMBIE)
        wakeup1(initproc);
    }
  }

  //added
  //cprintf("pid:%d  level:%d\n", curproc->pid, curproc->level);
  
  // Jump into the scheduler, never to return.
  curproc->state = ZOMBIE;
  sched();
  panic("zombie exit");
}

// Wait for a child process to exit and return its pid.
// Return -1 if this process has no children.
int
wait(void)
{
  struct proc *p;
  int havekids, pid;
  struct proc *curproc = myproc();
  
  acquire(&ptable.lock);
  for(;;){
    // Scan through table looking for exited children.
    havekids = 0;
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
      if(p->parent != curproc)
        continue;
      havekids = 1;
      if(p->state == ZOMBIE){
        // Found one.
        pid = p->pid;
        kfree(p->kstack);
        p->kstack = 0;
        freevm(p->pgdir);
        p->pid = 0;
        p->parent = 0;
        p->name[0] = 0;
        p->killed = 0;
        p->state = UNUSED;
        release(&ptable.lock);
        return pid;
      }
    }

    // No point waiting if we don't have any children.
    if(!havekids || curproc->killed){
      release(&ptable.lock);
      return -1;
    }

    // Wait for children to exit.  (See wakeup1 call in proc_exit.)
    sleep(curproc, &ptable.lock);  //DOC: wait-sleep
  }
}

//PAGEBREAK: 42
// Per-CPU process scheduler.
// Each CPU calls scheduler() after setting itself up.
// Scheduler never returns.  It loops, doing:
//  - choose a process to run
//  - swtch to start running that process
//  - eventually that process transfers control
//      via swtch back to the scheduler.
// void
// scheduler(void)
// {
//   struct proc *p;
//   struct cpu *c = mycpu();
//   c->proc = 0;
  
//   for(;;){
//     // Enable interrupts on this processor.
//     sti();

//     // Loop over process table looking for process to run.
//     acquire(&ptable.lock);
//     for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
//       if((p->state != RUNNABLE) || (p->level != 2))
//         continue;

//       // cprintf("scheduler***%d***p->priority:%d***p->level:%d\n", p->pid, p->priority, p->level);
//       // cprintf("ptable[0]:%d***p->priority:%d***p->level:%d\n", ptable.proc[0].pid, ptable.proc[0].priority, ptable.proc[0].level);

//       // Switch to chosen process.  It is the process's job
//       // to release ptable.lock and then reacquire it
//       // before jumping back to us.
//       c->proc = p;
//       switchuvm(p);
//       p->state = RUNNING;

//       swtch(&(c->scheduler), p->context);
//       switchkvm();

//       // Process is done running for now.
//       // It should have changed its p->state before coming back.
//       c->proc = 0;
//     }
//     release(&ptable.lock);

//   }
// }

void scheduler(void)
{
  struct proc *p;
  struct cpu *c = mycpu();
  c->proc = 0;

  for (;;)
  {
    // Enable interrupts on this processor.
    sti();

    acquire(&ptable.lock);
    // cprintf("p[0] with pid: %d and state: %d\n", ptable.proc->pid, ptable.proc->state);
    if (ptable.proc->pid == 0) {
      release(&ptable.lock);
      continue;
    }
    
    p = selectLevel1();
    if(p == 0) {
      p = selectLevel2();
    }
    if(p == 0) {
      p = selectLevel3();
    }
    if(p == 0) {
      p = selectLevel4();
    }
    // cprintf("tag7\n");
    if (p == 0) {
      release(&ptable.lock);
      continue;
    }
    incAge();
    p->execTime += 0.1;
    updateRank(p);
    p->age = 0;
    // p->rank += 0.1 * p->execTime_ratio;
    // if (p->priority < 100)
    //   cprintf("new Sched***pid:%d***state:%d\n", p->pid, p->state);
    // do
    c->proc = p;
    switchuvm(p);
    p->state = RUNNING;

    swtch(&(c->scheduler), p->context);
    switchkvm();
    c->proc = 0;
    // do
    release(&ptable.lock);
  }
}

// Enter scheduler.  Must hold only ptable.lock
// and have changed proc->state. Saves and restores
// intena because intena is a property of this
// kernel thread, not this CPU. It should
// be proc->intena and proc->ncli, but that would
// break in the few places where a lock is held but
// there's no process.
void
sched(void)
{
  int intena;
  struct proc *p = myproc();

  if(!holding(&ptable.lock))
    panic("sched ptable.lock");
  if(mycpu()->ncli != 1)
    panic("sched locks");
  if(p->state == RUNNING)
    panic("sched running");
  if(readeflags()&FL_IF)
    panic("sched interruptible");
  intena = mycpu()->intena;
  swtch(&p->context, mycpu()->scheduler);
  mycpu()->intena = intena;
}

// Give up the CPU for one scheduling round.
void
yield(void)
{
    // if (myproc()->level == 1 || myproc()->level == 2) {
	  acquire(&ptable.lock);  //DOC: yieldlock
	  myproc()->state = RUNNABLE;
	  sched();
	  release(&ptable.lock);
    // }
}

// A fork child's very first scheduling by scheduler()
// will swtch here.  "Return" to user space.
void
forkret(void)
{
  static int first = 1;
  // Still holding ptable.lock from scheduler.
  release(&ptable.lock);

  if (first) {
    // Some initialization functions must be run in the context
    // of a regular process (e.g., they call sleep), and thus cannot
    // be run from main().
    first = 0;
    iinit(ROOTDEV);
    initlog(ROOTDEV);
  }

  // Return to "caller", actually trapret (see allocproc).
}

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
  struct proc *p = myproc();
  
  if(p == 0)
    panic("sleep");

  if(lk == 0)
    panic("sleep without lk");

  // Must acquire ptable.lock in order to
  // change p->state and then call sched.
  // Once we hold ptable.lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup runs with ptable.lock locked),
  // so it's okay to release lk.
  if(lk != &ptable.lock){  //DOC: sleeplock0
    acquire(&ptable.lock);  //DOC: sleeplock1
    release(lk);
  }
  // Go to sleep.
  p->chan = chan;
  p->state = SLEEPING;

  sched();

  // Tidy up.
  p->chan = 0;

  // Reacquire original lock.
  if(lk != &ptable.lock){  //DOC: sleeplock2
    release(&ptable.lock);
    acquire(lk);
  }
}

//PAGEBREAK!
// Wake up all processes sleeping on chan.
// The ptable lock must be held.
static void
wakeup1(void *chan)
{
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if(p->state == SLEEPING && p->chan == chan)
      p->state = RUNNABLE;
}

// Wake up all processes sleeping on chan.
void
wakeup(void *chan)
{
  acquire(&ptable.lock);
  wakeup1(chan);
  release(&ptable.lock);
}

// Kill the process with the given pid.
// Process won't exit until it returns
// to user space (see trap in trap.c).
int
kill(int pid)
{
  struct proc *p;

  acquire(&ptable.lock);
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->pid == pid){
      p->killed = 1;
      // Wake process from sleep if necessary.
      if(p->state == SLEEPING)
        p->state = RUNNABLE;
      release(&ptable.lock);
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}

//PAGEBREAK: 36
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
  static char *states[] = {
  [UNUSED]    "unused",
  [EMBRYO]    "embryo",
  [SLEEPING]  "sleep ",
  [RUNNABLE]  "runble",
  [RUNNING]   "run   ",
  [ZOMBIE]    "zombie"
  };
  int i;
  struct proc *p;
  char *state;
  uint pc[10];

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    cprintf("%d %s %s", p->pid, state, p->name);
    if(p->state == SLEEPING){
      getcallerpcs((uint*)p->context->ebp+2, pc);
      for(i=0; i<10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
  }
}

// added
int
giveParent(int pid)
{
  struct proc *p;
  int parent = -1;

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->pid == pid)
    {
      parent = p->parent->pid;
      break;
    }
  }

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->pid == parent)
    {
      return parent;
    }
  }

  return -1;
}

// added
int
giveYoungestChild(int pid)
{
  struct proc *p;
  int youngestChild = -1;

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->pid == pid)
    {
      if (p->hasChild)
        youngestChild = p->youngestChild->pid;
      break;
    }
  }

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++)
  {
    if (p->pid == youngestChild)
    {
      return youngestChild;
    }
  }

  return -1;
}
