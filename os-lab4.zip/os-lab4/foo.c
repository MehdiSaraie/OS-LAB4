#include "types.h"
#include "stat.h"
#include "user.h"

#define CALC 300000000
#define N 5
#define DELAY 200
#define STDOUT 1

void child(int id) {
    int pid = getpid();
    sleep(id*100);

    float r = 0;
    while(1) {
        r++;
        if (r > CALC) break;
    }
    printf(STDOUT, "ID: %d, PID: %d\n", id, pid);
    exit();
}

int main(int argc, char *argv[]) {
    printf(STDOUT, "parent PID: %d\n", getpid());
    for (int i=0; 1; i++) {
        if(!fork()) {
            child(i);
        }
        if(i == N - 1) {
            wait();
            i--;
        }
        sleep(DELAY);
    }

    exit();
}
