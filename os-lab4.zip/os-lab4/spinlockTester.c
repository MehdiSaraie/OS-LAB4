#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
    spinlockTest(10);
    exit();
}